1. Please refer to the gps_cfg.inf and Modify the module type,NMEA port path and Baudrate, but you must to make sure the file's format is Linux.
2. Please refer to the "Quectel_Android_GPS_Driver_User_Guide_V1.0" to integrate the GPS driver.
2. If have any problem to integrate the gps driver, Please run the "logcat -s gps_ql -v time" to record the GPS log and contact with quectel.